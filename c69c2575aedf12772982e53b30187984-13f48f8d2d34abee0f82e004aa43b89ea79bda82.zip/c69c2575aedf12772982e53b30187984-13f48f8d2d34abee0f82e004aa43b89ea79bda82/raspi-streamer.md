Setting up a Raspberry Pi for use as an audio streamer

TODO
- Automate setup of spotify in the browser (autofill login etc), probbaly using selenium
-- This is probably needed in a caretaker process too, keep an eye on Spotify and reload if "something went wrong" message comes up
- Implement exclusive playback between spotify / shairport: if one starts playing, the other stops